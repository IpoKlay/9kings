# 鹰旗之下

全屏像素军团策略 Demo。建设营地、选择补给、部署三路军队，守过三轮进攻。

![试玩画面](preview.png)

## 试玩

下载本仓库后，直接用浏览器打开 `index.html`，无需安装或联网。线上试玩地址将在 GitHub Pages 部署后补充。

- 三张补给卡任选一张，也支持键盘 1 / 2 / 3。
- 建筑卡点击营地空格建造，或点击同类建筑升级。
- 点击兵营可调整上、中、下路；点击“出征”开始战斗。
- 战斗可暂停、加速，M 切换静音。

## 设计文档

- [初步方案：123.pdf](documents/123.pdf)
- [鹰旗之下：完整图像 Prompt 手册](documents/鹰旗之下-完整图像Prompt手册.pdf)

## 开发

`index.html` 是含全部资源的独立试玩版；`dist/` 是拆分后的 HTML、CSS、JavaScript 与音频资源。开发说明见 [DEVELOPMENT.md](DEVELOPMENT.md)。

规则检查：`node --test tests/engine.test.js tests/feedback.test.js`。

音频素材授权与来源见 [AUDIO-CREDITS.txt](dist/AUDIO-CREDITS.txt)。
