"""Build edited CC0 recordings into a portable PCM bank. See dist/AUDIO-CREDITS.txt."""
from pathlib import Path
import json,base64,argparse
import numpy as np
import soundfile as sf
from scipy.signal import butter,sosfilt,resample_poly
parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,required=True,help='Folder containing extracted CC0 source packs');RAW=parser.parse_args().source;OUT=Path(__file__).resolve().parents[1]/'dist';RATE=24000
bank={};manifest={}
def read(path,maximum=.5,low=70,high=6500,pitch=1):
 x,sr=sf.read(path,always_2d=True);x=x.mean(axis=1);x=resample_poly(x,RATE,sr)
 if pitch!=1:x=np.interp(np.arange(0,len(x),pitch),np.arange(len(x)),x)
 # Trim leading silence against a 2 ms RMS envelope; preserve the contact transient.
 energy=np.convolve(x*x,np.ones(48)/48,'same');valid=np.flatnonzero(energy>max(energy.max()*.008,.000001))
 if len(valid):x=x[max(0,int(valid[0])-48):int(valid[-1])+120]
 x=sosfilt(butter(2,[low,high],btype='bandpass',fs=RATE,output='sos'),x)
 x=x[:int(maximum*RATE)]
 if len(x)<16:raise ValueError(path)
 x/=max(np.max(np.abs(x)),.001)
 return x

def mix(*layers,duration=None):
 size=int(duration*RATE) if duration else max(len(x)+int(at*RATE) for x,gain,at in layers)
 out=np.zeros(size)
 for x,gain,at in layers:
  start=int(at*RATE);n=min(len(x),size-start)
  if n>0:out[start:start+n]+=x[:n]*gain
 return out

def save(name,x,peak=.79,tail=.055):
 x=x.copy();fade=min(int(tail*RATE),len(x)//2);x[-fade:]*=np.linspace(1,0,fade)**1.5;x[:24]*=np.linspace(0,1,24)
 x-=x.mean();x*=peak/max(np.max(np.abs(x)),.001);x[0]=x[-1]=0
 pcm=(x*32767).astype('<i2');bank[name]=base64.b64encode(pcm.tobytes()).decode()
 sf.write(OUT/'audio'/f'{name}.wav',x,RATE,subtype='PCM_16')
 manifest[name]={'duration':round(len(x)/RATE,3),'peak':round(float(abs(x).max()),4),'rms':round(float(np.sqrt(np.mean(x*x))),4)}
 return x

def impact(kind,i,maxlen=.24,pitch=1):return read(RAW/'impact/Audio'/f'{kind}_{i:03}.ogg',maxlen,pitch=pitch)
swishes=[];hits=[]
for i in range(3):
 sw=read(RAW/'battle/battle_sound_effects'/f'swish_{i+2}.wav',.16,high=5500,pitch=1.15)
 swishes.append(sw);save(f'swing{i}',sw,.46,.04)
 blade=read(RAW/'clashes'/f'sword_clash.{i+1}.ogg',.28,low=190,high=5700,pitch=.84+i*.035)
 body=impact('impactPunch_heavy',i,.2,.91)
 hit=save(f'sword{i}',mix((blade,.62,0),(body,.72,0)),.85,.085);hits.append(hit)
 save(f'impact{i}',body,.72)
 metal=impact('impactMetal_heavy',i,.30,.87)
 wood=impact('impactWood_heavy',i,.20,.94)
 save(f'shield{i}',mix((metal,.55,0),(wood,.62,0)),.8,.10)
 save(f'kill{i}',mix((body,.88,0),(metal,.38,.018),(wood,.35,.035)),.89,.07)
 save(f'foot{i}',impact('footstep_grass',i,.11),.32,.025)
arrow=read(RAW/'battle/battle_sound_effects/Bow.wav',.24,high=6200)
save('arrow0',arrow,.62)
wood=impact('impactWood_heavy',3,.18)
plate=impact('impactPlate_heavy',1,.33,.82)
save('break0',mix((plate,.5,0),(wood,.7,0),(hits[0],.25,.06)),.85,.07)
save('build0',mix((wood,.7,0),(impact('impactWood_medium',2,.14),.25,.1)),.7)
# Original arcade UI cues: tactile onset, clean tonal confirmation, no borrowed game audio.
def note(freq,duration=.11):
 t=np.arange(int(duration*RATE))/RATE
 # A rounded triangle with a quiet octave: bright but no abrasive square-wave buzz.
 phase=2*np.pi*freq*t
 wave=np.sin(phase)+.13*np.sin(3*phase)+.045*np.sin(5*phase)
 env=(1-np.exp(-t/.0015))*np.exp(-t/.028)
 return wave*env
click=impact('impactWood_light',0,.055,pitch=1.35)
save('hover0',mix((click,.8,0),(note(740,.04),.10,0)),.16,.018)
save('click0',mix((click,.55,0),(note(523,.075),.40,0),(note(1046,.06),.12,.014)),.42,.025)
save('select0',mix((click,.5,0),(note(659,.10),.60,0),(note(988,.11),.44,.045),(note(1318,.13),.3,.09)),.58,.04)
save('upgrade0',mix((wood,.35,0),(note(523,.13),.5,0),(note(659,.13),.45,.05),(note(784,.13),.4,.10),(note(1046,.2),.35,.15)),.65,.07)
save('bad0',impact('impactSoft_heavy',0,.25,.78),.63)
# A short physical stomp replaces the old nasal oscillator horn.
save('horn0',mix((impact('impactSoft_heavy',2,.24,.78),.8,0),(wood,.25,.09)),.72)
# Real voices, edited into a brief unison shout with a subdued crowd bed.
crowd=read(RAW/'crowd.ogg',1.1,low=170,high=3600,pitch=.92)
voices=[read(RAW/'voices/yelling sounds'/name,.65,low=100,high=4000,pitch=p) for name,p in [('3grunt1.wav',.94),('3grunt2.wav',.88),('3grunt3.wav',1.02)]]
for i in range(2):
 save(f'cry{i}',mix((voices[i],.65,0),(voices[(i+1)%3],.45,.045),(voices[(i+2)%3],.35,.085),(crowd,.20,.015),duration=.95),.7,.16)
save('win0',mix((hits[0],.4,0),(wood,.45,.16),(plate,.22,.31),duration=.55),.68,.12)
(OUT/'audio-bank.js').write_text('/* Edited CC0 combat recordings and original UI cues. Credits: AUDIO-CREDITS.txt. */\n(function(root){const bank='+json.dumps({'rate':RATE,'samples':bank},separators=(',',':'))+';if(typeof module!=="undefined"&&module.exports)module.exports=bank;root.EagleAudioBank=bank;})(typeof window!=="undefined"?window:globalThis);\n')
(OUT/'audio/manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({'samples':len(bank),'total_seconds':round(sum(v['duration'] for v in manifest.values()),2),'bank_kb':round((OUT/'audio-bank.js').stat().st_size/1024)},indent=2))
