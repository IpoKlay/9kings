"""Bundle this buildless game into a single offline HTML and a portable ZIP."""
from pathlib import Path
import re,zipfile
ROOT=Path(__file__).resolve().parents[1]
html=(ROOT/'dist/index.html').read_text()
html=html.replace('<link rel="stylesheet" href="style.css">','<style>'+ (ROOT/'dist/style.css').read_text()+'</style>')
html=re.sub(r'<script src="([^"]+)"></script>',lambda m:'<script>\n'+(ROOT/'dist'/m[1]).read_text().replace('</script','<\\/script')+'\n</script>',html)
html+='\n<!--\n'+(ROOT/'dist/AUDIO-CREDITS.txt').read_text().replace('--','—')+'\n-->\n'
(ROOT/'鹰旗之下-Demo.html').write_text(html)
with zipfile.ZipFile(ROOT/'鹰旗之下-Demo.zip','w',zipfile.ZIP_DEFLATED) as z:
 for path in [ROOT/'鹰旗之下-Demo.html',ROOT/'README.md',*sorted((ROOT/'dist').rglob('*')),*sorted((ROOT/'scripts').glob('*')),*sorted((ROOT/'tests').glob('*.js')),*sorted(ROOT.glob('preview*.png'))]:
  if path.is_file():z.write(path,path.relative_to(ROOT))
print('Offline HTML and ZIP updated.')
