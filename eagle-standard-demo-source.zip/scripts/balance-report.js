/* Deterministic balance probes; no browser or rendering required. */
const E=require('../dist/engine.js');
const fight=g=>{E.skip(g);E.start(g);let n=0;while(g.phase==='battle'&&n++<2400)E.step(g,1/30);return g.battle.report;};
const opening=[1,2,3,4,6,8,10].map(year=>{const g=E.createGame(1);g.round=year;const report=fight(g);return{year,won:report.won,surviving:report.surviving,enemyLosses:report.enemyLosses,enemies:report.enemyCount};});
function campaign(seed,smart){const g=E.createGame(seed);for(let year=1;year<=24&&g.defense>0;year++){
 const cards=E.offers(g);const value=id=>{const count=t=>g.buildings.filter(b=>b.type===t).length,types=new Set(g.buildings.map(b=>b.type)),doctrine=E.CARDS[id].kind==='Permanent';if(E.TYPES[id])return id==='training'?2:id==='medic'?(count(id)?2:10):id==='guard'?(count(id)?4:9):id==='spear'?(count(id)?4:8):7-count(id);if(id==='combinedArms')return types.size+4;if(id==='fireArrows'||id==='oilShots'||id==='pinning')return 8;if(id==='fieldMedicine')return 8;return doctrine?6:1;};
 const id=smart?[...cards].sort((a,b)=>value(b)-value(a))[0]:cards[seed%3];E.choose(g,id);if(g.phase==='place'){const empty=Array.from({length:12},(_,i)=>i).find(i=>!g.buildings.some(b=>b.cell===i)),upgrade=g.buildings.find(b=>b.type===g.pending&&b.level<3);E.place(g,empty??upgrade.cell);}fight(g);if(g.phase==='result')E.next(g);else break;
 }return g.round;}
const runs=smart=>{const a=Array.from({length:20},(_,i)=>campaign(i+1,smart)).sort((a,b)=>a-b);return{min:a[0],median:a[10],max:a.at(-1),surviveYear3:a.filter(v=>v>3).length,surviveYear10:a.filter(v=>v>10).length};};
function pair(year,upgrades){const g=E.createGame(1);g.round=year;g.buildings=['guard','legion','spear','archer','archer','siege','medic'].map((type,i)=>({type,id:i+1,cell:i,level:1}));g.upgrades=upgrades;const r=fight(g);return{won:r.won,surviving:r.surviving,enemyLosses:r.enemyLosses,time:Number(g.battle.time.toFixed(1))};}
const synergies=[8,12,16,20].map(year=>({year,plain:pair(year,{}),combined:pair(year,{fireArrows:1,oilShots:1,pinning:1,shieldDrill:2,fieldMedicine:1,crossfire:1,combinedArms:1})}));
console.log(JSON.stringify({opening,random:runs(false),construction:runs(true),synergies},null,2));
