'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const I=require('../dist/isometric.js');
test('camera round trips every tile and combat lane without changing logical positions',()=>{
 for(let x=0;x<=1600;x+=40)for(let y=0;y<=900;y+=30){const p=I.project(x,y),w=I.unproject(p.x,p.y);assert(Math.abs(x-w.x)<1e-8);assert(Math.abs(y-w.y)<1e-8);}
 for(let cell=0;cell<12;cell++){const c=I.cellCenter(cell),p=I.project(c.x,c.y),corners=I.cellPolygon(cell,0);assert(Math.abs(corners.reduce((n,q)=>n+q.x,0)/4-p.x)<1e-8);assert(Math.abs(corners.reduce((n,q)=>n+q.y,0)/4-p.y)<1e-8);}
});
test('elevation remains vertical and shared tile edges meet exactly',()=>{
 const p=I.project(500,600),up=I.project(500,600,70);assert.equal(p.x,up.x);assert.equal(p.y-up.y,70);
 for(let row=0;row<3;row++)for(let col=0;col<3;col++){const a=I.cellPolygon(row*4+col,0),b=I.cellPolygon(row*4+col+1,0);assert.deepEqual(a[1],b[0]);assert.deepEqual(a[2],b[3]);}
});
test('projected combat and building effects stay on the same camera as their subjects',()=>{
 const vm=require('node:vm'),fs=require('node:fs'),scope={window:{EagleIso:I},Math};vm.runInNewContext(fs.readFileSync(require.resolve('../dist/feedback.js'),'utf8'),scope);
 const fx=scope.window.EagleFeedback({play(){}}),positions=new Map([[12,900]]);fx.consume([{kind:'death',id:12,x:400,lane:2,side:'enemy'}],positions);const route=fx.routed(12);assert.equal(route.worldX,900);assert.equal(route.x,I.project(900,650).x);
 fx.clear();fx.build(10,false);const texts=[];const ctx=new Proxy({strokeText:(text,x,y)=>texts.push({text,x,y})},{get:(o,k)=>k in o?o[k]:()=>{},set:(o,k,v)=>(o[k]=v,true)});fx.draw(ctx);const pos=I.cellCenter(10),p=I.project(pos.x,pos.y);assert.equal(texts[0].x,p.x);assert.equal(texts[0].y,p.y-72);
});
