'use strict';
const assert=require('node:assert/strict');
const {test}=require('node:test');
const E=require('../dist/engine.js');
const A=require('../dist/audio.js');
test('combat events report actual health loss, shield absorption and one death per unit',()=>{
  const g=E.createGame();E.skip(g);E.start(g);
  const ally=g.battle.units.find(u=>u.type==='legion'),enemy=g.battle.units.find(u=>u.side==='enemy');
  g.battle.units=[ally,enemy];ally.x=400;enemy.x=425;ally.y=enemy.y=0;ally.cooldown=enemy.cooldown=0;
  enemy.shield=7;enemy.hp=3;ally.attack=20;
  E.step(g,1/30);
  const hit=g.battle.events.find(e=>e.kind==='hit'&&e.id===enemy.id);
  assert.equal(hit.damage,3);assert.equal(hit.absorbed,7);assert.equal(hit.broken,true);
  assert.equal(g.battle.events.filter(e=>e.kind==='death'&&e.id===enemy.id).length,1);
  assert.equal(ally.hp,139,'Simultaneous attack must still apply');assert.equal(g.battle.report.won,true);
});
test('feedback events are transient and do not repeat shield impacts on idle steps',()=>{
  const g=E.createGame();g.round=2;g.offered=['shield'];g.offerYear=2;E.choose(g,'shield');E.start(g);
  const ally=g.battle.units.find(u=>u.type==='legion'),enemy=g.battle.units.find(u=>u.side==='enemy');
  g.battle.units=[ally,enemy];ally.x=400;enemy.x=425;ally.y=enemy.y=0;ally.cooldown=enemy.cooldown=0;E.step(g,1/30);
  const hit=g.battle.events.find(e=>e.kind==='hit'&&e.id===ally.id);
  assert.equal(hit.damage,0);assert.equal(hit.absorbed,enemy.attack);assert.equal(hit.broken,false);
  E.step(g,1/30);assert.equal(g.battle.events.length,0);
});
test('recorded bank decodes finite bounded PCM with short tails and silent edges',()=>{
  const bank=require('../dist/audio-bank.js');
  assert.equal(bank.rate,24000);assert.equal(Object.keys(bank.samples).length,30);
  for(const [name,encoded] of Object.entries(bank.samples)){
    const data=A.decode(encoded);let power=0,peak=0;
    for(const x of data){assert(Number.isFinite(x),name);power+=x*x;peak=Math.max(peak,Math.abs(x));}
    assert(peak<=.9,name);assert(power/data.length>.000001,name+' must not be silent');
    assert.equal(data[0],0);assert.equal(data.at(-1),0);
    assert(data.length/bank.rate <= (name.startsWith('cry')?1:.6),name+' tail is too long');
  }
});
const V=require('../dist/battle-view.js');
test('nine soldiers have unique positions and independent sword wind-up, cut and recovery',()=>{
  assert.equal(V.formation.length,9);assert.equal(new Set(V.formation.map(p=>p.dx+','+p.dy)).size,9);
  const lift=V.pose(0,0,false,.03),cut=V.pose(0,0,false,.12),rest=V.pose(0,0,false,.6);
  assert(lift.sword<-1);assert(cut.slash>.8);assert(cut.thrust>7);assert.equal(rest.sword,0);
  assert.notEqual(V.pose(.1,0,true,10).stride,V.pose(.1,1,true,10).stride);
  assert.equal(V.pose(.1,0,true,.12,true).slash,0);
});
test('render positions preserve physical combat positions without lane compression',()=>{
 const units=[{id:1,hp:10,x:400,y:-80},{id:2,hp:10,x:400,y:80},{id:3,hp:0,x:434,y:0}],before=JSON.stringify(units),pos=V.layout(units);
 assert.equal(pos.get(1),959);assert.equal(pos.get(2),959);assert(!pos.has(3));assert.equal(JSON.stringify(units),before);
});
test('hit reactions do not erase sword animation and paused effects stay frozen',()=>{
  const vm=require('node:vm'),fs=require('node:fs');const scope={window:{},Math};vm.runInNewContext(fs.readFileSync(require.resolve('../dist/feedback.js'),'utf8'),scope);
  const calls=[],fx=scope.window.EagleFeedback({play:(...args)=>calls.push(args)});
  fx.consume([{kind:'attack',id:1,target:2,x:400,lane:0,side:'ally',ranged:false},{kind:'hit',id:1,x:400,lane:0,side:'ally',damage:10,absorbed:0}]);
  fx.tick(.12,false);assert.equal(fx.attackAge(1),.12);const t=fx.time;fx.tick(5,true);assert.equal(fx.time,t);
  fx.consume([{kind:'death',id:2,x:430,lane:0,side:'enemy'}]);assert(fx.frozen);assert.equal(fx.routed(2).age,0);
  fx.clear();assert(!fx.frozen);assert.equal(fx.routed(2),null);
});

test('automatic army reserves retain unique world-space positions',()=>{
 const g=E.createGame();g.buildings.push({id:4,type:'legion',cell:5,level:1},{id:5,type:'archer',cell:6,level:1});
 const units=E.muster(g).filter(u=>u.side==='ally'),p=V.layout(units);assert.equal(new Set(units.map(u=>p.get(u.id)+','+u.y)).size,units.length);
});

test('blood and fallen soldiers persist on the ground and clear between battles',()=>{
 const vm=require('node:vm'),fs=require('node:fs'),scope={window:{},Math};vm.runInNewContext(fs.readFileSync(require.resolve('../dist/feedback.js'),'utf8'),scope);
 const fx=scope.window.EagleFeedback({play(){}}),marks=[];
 const ctx=new Proxy({fillRect:(...args)=>marks.push(args)},{get:(o,k)=>k in o?o[k]:()=>{},set:(o,k,v)=>(o[k]=v,true)});
 fx.consume([{kind:'death',id:4,x:400,y:0,side:'enemy'}]);fx.tick(8,false);fx.drawGround(ctx);assert(marks.length>10);
 fx.clear();marks.length=0;fx.drawGround(ctx);assert.equal(marks.length,0);
 for(let i=0;i<1000;i++)fx.consume([{kind:'hit',id:1,x:400,y:0,side:'ally',damage:5,absorbed:0}]);marks.length=0;fx.drawGround(ctx);assert(marks.length<=900,'Ground marks must remain bounded');
});
