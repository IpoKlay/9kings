'use strict';
const assert=require('node:assert/strict');
const {test}=require('node:test');
const E=require('../dist/engine.js');
const A=require('../dist/audio.js');
test('combat events report actual health loss, shield absorption and one death per unit',()=>{
  const g=E.createGame();E.skip(g);E.start(g);
  const ally=g.battle.units.find(u=>u.type==='legion'),enemy=g.battle.units.find(u=>u.side==='enemy');
  g.battle.units=[ally,enemy];ally.x=400;enemy.x=425;ally.cooldown=enemy.cooldown=0;
  enemy.shield=7;enemy.hp=3;ally.attack=20;
  E.step(g,1/30);
  const hit=g.battle.events.find(e=>e.kind==='hit'&&e.id===enemy.id);
  assert.equal(hit.damage,3);assert.equal(hit.absorbed,7);assert.equal(hit.broken,true);
  assert.equal(g.battle.events.filter(e=>e.kind==='death'&&e.id===enemy.id).length,1);
  assert.equal(ally.hp,110,'Simultaneous attack must still apply');assert.equal(g.battle.lanes[0],'held');
});
test('feedback events are transient and do not repeat shield impacts on idle steps',()=>{
  const g=E.createGame();g.round=2;E.choose(g,'shield');E.setShield(g,0);E.start(g);
  const ally=g.battle.units.find(u=>u.type==='legion'),enemy=g.battle.units.find(u=>u.side==='enemy'&&u.lane===0);
  g.battle.units=[ally,enemy];ally.x=400;enemy.x=425;ally.cooldown=enemy.cooldown=0;E.step(g,1/30);
  const hit=g.battle.events.find(e=>e.kind==='hit'&&e.id===ally.id);
  assert.equal(hit.damage,0);assert.equal(hit.absorbed,10);assert.equal(hit.broken,false);
  E.step(g,1/30);assert.equal(g.battle.events.length,0);
});
test('recorded bank decodes finite bounded PCM with short tails and silent edges',()=>{
  const bank=require('../dist/audio-bank.js');
  assert.equal(bank.rate,24000);assert.equal(Object.keys(bank.samples).length,30);
  for(const [name,encoded] of Object.entries(bank.samples)){
    const data=A.decode(encoded);let power=0,peak=0;
    for(const x of data){assert(Number.isFinite(x),name);power+=x*x;peak=Math.max(peak,Math.abs(x));}
    assert(peak<=.9,name);assert(power/data.length>.000001,name+' must not be silent');
    assert.equal(data[0],0);assert.equal(data.at(-1),0);
    assert(data.length/bank.rate <= (name.startsWith('cry')?1:.6),name+' tail is too long');
  }
});
const V=require('../dist/battle-view.js');
test('nine soldiers have unique positions and independent sword wind-up, cut and recovery',()=>{
  assert.equal(V.formation.length,9);assert.equal(new Set(V.formation.map(p=>p.dx+','+p.dy)).size,9);
  const lift=V.pose(0,0,false,.03),cut=V.pose(0,0,false,.12),rest=V.pose(0,0,false,.6);
  assert(lift.sword<-1);assert(cut.slash>.8);assert(cut.thrust>7);assert.equal(rest.sword,0);
  assert.notEqual(V.pose(.1,0,true,10).stride,V.pose(.1,1,true,10).stride);
  assert.equal(V.pose(.1,0,true,.12,true).slash,0);
});
test('formation layout separates reserves without mutating combat coordinates',()=>{
  const units=[{id:1,hp:10,x:400,lane:0,side:'ally'},{id:2,hp:10,x:400,lane:0,side:'ally'},{id:3,hp:10,x:434,lane:0,side:'enemy'}];
  const before=JSON.stringify(units),pos=V.layout(units);
  assert(pos.get(1)-pos.get(2)>=80);assert(pos.get(3)>pos.get(1));assert.equal(JSON.stringify(units),before);
});
test('hit reactions do not erase sword animation and paused effects stay frozen',()=>{
  const vm=require('node:vm'),fs=require('node:fs');const scope={window:{},Math};vm.runInNewContext(fs.readFileSync(require.resolve('../dist/feedback.js'),'utf8'),scope);
  const calls=[],fx=scope.window.EagleFeedback({play:(...args)=>calls.push(args)});
  fx.consume([{kind:'attack',id:1,target:2,x:400,lane:0,side:'ally',ranged:false},{kind:'hit',id:1,x:400,lane:0,side:'ally',damage:10,absorbed:0}]);
  fx.tick(.12,false);assert.equal(fx.attackAge(1),.12);const t=fx.time;fx.tick(5,true);assert.equal(fx.time,t);
  fx.consume([{kind:'death',id:2,x:430,lane:0,side:'enemy'}]);assert(fx.frozen);assert.equal(fx.routed(2).age,0);
  fx.clear();assert(!fx.frozen);assert.equal(fx.routed(2),null);
});

test('large reserves remain distinct at the camp boundary',()=>{
 const units=Array.from({length:6},(_,id)=>({id,hp:1,x:165-id*40,lane:0,side:'ally'}));
 const p=V.layout(units),xs=[...p.values()];assert(Math.min(...xs)>=625);assert(Math.max(...xs)<=1535);assert.equal(new Set(xs).size,6);
});
