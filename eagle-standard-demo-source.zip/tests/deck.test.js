'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),E=require('../dist/engine.js');
const pick=(g,id)=>{g.offered=[id];g.offerYear=g.round;return E.choose(g,id);};
const u=(id,side,type,x,extra={})=>({id,side,type,x,y:0,hp:100,maxHp:100,attack:10,range:72,speed:0,interval:1,shield:0,cooldown:99,flash:0,...extra});
function setup(units,upgrades={}){const g=E.createGame(1);g.upgrades=upgrades;E.skip(g);E.start(g);g.battle.units=units;g.battle.initialAllies=units.filter(v=>v.side==='ally').length;g.battle.initialEnemies=units.filter(v=>v.side==='enemy').length;return g;}
function shot(g,target,extra={}){g.battle.projectiles.push({target:target.id,side:'ally',life:.01,damage:20,...extra});}
test('24-card pool: seed variety, stable offers, unique actionable choices and no consecutive repeats',()=>{
 assert.equal(Object.keys(E.CARDS).length,24);const first=new Set();for(let seed=0;seed<50;seed++){const g=E.createGame(seed);first.add(E.offers(g).join(','));let previous=[];for(let year=1;year<=40;year++){g.round=year;const cards=E.offers(g);assert.equal(new Set(cards).size,3);assert(cards.every(id=>E.canChoose(g,id)));assert(cards.every(id=>!previous.includes(id)));assert.deepEqual(E.offers(g),cards);cards.pop();assert.equal(E.offers(g).length,3);previous=E.offers(g);}}assert(first.size>20);
});
test('unoffered cards are rejected and capped / unsupported upgrades are filtered',()=>{
 const g=E.createGame(7),ids=E.offers(g);assert(!E.choose(g,Object.keys(E.CARDS).find(id=>!ids.includes(id))));assert(!E.available(g,'charge'));assert(!E.available(g,'fieldMedicine'));assert(!E.available(g,'oilShots'));g.upgrades.fireArrows=1;assert(E.available(g,'oilShots'));g.upgrades.crossfire=2;assert(!E.available(g,'crossfire'));g.buildings.push({id:5,type:'cavalry',cell:5,level:1});assert(E.available(g,'charge'));
});
test('fully capped camp still gets three distinct single-battle orders indefinitely',()=>{
 const g=E.createGame(9);g.buildings=Array.from({length:12},(_,i)=>({id:i,cell:i,level:3,type:'legion'}));for(const [id,c]of Object.entries(E.CARDS))if(c.max)g.upgrades[id]=c.max;
 for(let i=1;i<500;i++){g.round=i;const cards=E.offers(g);assert.equal(new Set(cards).size,3);assert(cards.every(id=>E.CARDS[id].kind==='Battle order'&&E.canChoose(g,id)));}
});
test('permanent ranks persist, temporary orders expire, and all new roles assemble uniquely',()=>{
 const g=E.createGame(5);pick(g,'shieldDrill');g.phase='result';E.next(g);assert.equal(g.upgrades.shieldDrill,1);pick(g,'rally');assert.equal(E.stats(g,g.buildings[0]).attack,17.5);g.phase='result';E.next(g);assert.equal(E.stats(g,g.buildings[0]).attack,14);
 for(const type of ['spear','guard','cavalry','medic']){g.buildings.push({id:g.nextId++,type,cell:g.nextId+2,level:1});}const army=E.muster(g).filter(v=>v.side==='ally');assert.equal(army.length,7);assert.equal(new Set(army.map(v=>v.x+','+v.y)).size,7);assert.equal(army.find(v=>v.type==='guard').shield,50);assert(army.filter(v=>E.TYPES[v.type].role==='front').every(v=>v.shield>=20));assert.equal(army.find(v=>v.type==='medic').shield,0);assert(army.filter(v=>E.TYPES[v.type].role==='front').every(v=>v.x>army.find(v=>v.type==='archer').x));
});
test('fire arrows refresh a bounded burn and pitch stones amplify damage only on burning targets',()=>{
 const a=u(1,'ally','archer',0),b=u(2,'enemy','enemy',300,{hp:1000,maxHp:1000});const g=setup([a,b],{fireArrows:1,oilShots:1});shot(g,b,{fire:true});E.step(g,.02);assert.equal(b.hp,980);const expiry=b.burnUntil;E.step(g,.1);assert(Math.abs(b.hp-979.7)<.001);shot(g,b,{fire:true});E.step(g,.02);assert(b.burnUntil>expiry);const before=b.hp;shot(g,b,{siege:true,to:b.x,toY:0});E.step(g,.02);assert(Math.abs(before-b.hp-30.06)<.001);b.burnUntil=0;const clean=b.hp;shot(g,b,{siege:true,to:b.x,toY:0});E.step(g,.02);assert.equal(clean-b.hp,20);
});
test('spears slow opponents and Pin & Pierce increases ranged damage; Crossfire needs engagement',()=>{
 const spear=u(1,'ally','spear',200,{range:110,cooldown:0}),foe=u(2,'enemy','enemy',280),archer=u(3,'ally','archer',0);const g=setup([spear,foe,archer],{pinning:1,crossfire:1});E.step(g,.02);assert(foe.slowUntil>g.battle.time);const before=foe.hp;shot(g,foe);E.step(g,.02);assert(Math.abs(before-foe.hp-31)<.0001);spear.x=0;foe.slowUntil=0;const after=foe.hp;shot(g,foe);E.step(g,.02);assert.equal(after-foe.hp,20);
});
test('medics heal wounded allies without attacking, over-healing or resurrecting',()=>{
 const medic=u(1,'ally','medic',100,{heal:18,range:280,cooldown:0}),friend=u(2,'ally','guard',200,{hp:90}),dead=u(3,'ally','legion',250,{hp:0}),foe=u(4,'enemy','enemy',500);const g=setup([medic,friend,dead,foe]);E.step(g,.02);assert.equal(friend.hp,100);assert.equal(dead.hp,0);assert.equal(foe.hp,100);assert(g.battle.events.some(e=>e.kind==='heal'&&e.amount===10));
 const h=E.createGame();h.buildings.push({id:4,type:'medic',cell:3,level:1});h.upgrades.fieldMedicine=2;assert.equal(E.muster(h).find(v=>v.type==='medic').heal,24);
});
test('cavalry charges once, with Shock Charge upgrade; enemy defeat triggers nearby haste',()=>{
 const horse=u(1,'ally','cavalry',200,{cooldown:0}),foe=u(2,'enemy','enemy',250,{hp:1000,maxHp:1000});const g=setup([horse,foe],{charge:1,warhorn:1});E.step(g,.02);assert.equal(foe.hp,978);assert(horse.charged);horse.cooldown=0;E.step(g,.02);assert.equal(foe.hp,968);foe.hp=1;horse.cooldown=0;E.step(g,.02);assert(horse.hasteUntil>g.battle.time);
});
test('diversity and volley affect only allies; enemy difficulty is unchanged at year 100000',()=>{
 const g=E.createGame();const initial=E.muster(g).filter(v=>v.side==='enemy');g.upgrades.combinedArms=1;assert(Math.abs(E.stats(g,g.buildings[0]).attack-16.1)<.001);g.orders.volley=true;assert(Math.abs(E.stats(g,g.buildings[1]).interval-1.2/1.4)<.001);assert.equal(E.stats(g,g.buildings[0]).interval,1);g.round=100000;assert.deepEqual(E.muster(g).filter(v=>v.side==='enemy'),initial);
});
test('100 random campaigns progress with legal placements, finite stats and fixed enemy count',()=>{
 for(let seed=1;seed<=100;seed++){const g=E.createGame(seed);for(let year=1;year<=12&&g.phase!=='defeat';year++){const choices=E.offers(g);assert(E.choose(g,choices[seed%3]));if(g.phase==='place'){const cell=Array.from({length:12},(_,i)=>i).find(i=>!g.buildings.some(b=>b.cell===i)||g.buildings.some(b=>b.cell===i&&b.type===g.pending&&b.level<3));assert(E.place(g,cell));}assert(E.start(g));let n=0;while(g.phase==='battle'&&n++<800)E.step(g,.1);assert.notEqual(g.phase,'battle');assert.equal(g.battle.initialEnemies,3);assert(g.battle.units.every(v=>Number.isFinite(v.hp)&&v.hp>=0&&Number.isFinite(v.x)&&Number.isFinite(v.y)));if(g.phase==='result')assert(E.next(g));}}
});
