'use strict';
const assert = require('node:assert/strict');
const { test } = require('node:test');
const E = require('../dist/engine.js');
const play = g => { let frames = 0; while (g.phase === 'battle' && frames++ < 1900) E.step(g, 1 / 30); assert.notEqual(g.phase, 'battle', 'Battle must terminate'); };

test('cards can only be granted once, invalid placements preserve the pending card', () => {
  const g = E.createGame(); assert(E.choose(g, 'training')); assert(!E.choose(g, 'legion')); assert(!E.place(g, 0)); assert.equal(g.phase, 'place'); assert(E.place(g, 1)); assert(!E.place(g, 3)); assert.equal(g.buildings.length, 3);
});
test('orthogonal training buffs both neighbours, never diagonals, with no cumulative stat mutation', () => {
  const g = E.createGame(); E.choose(g, 'training'); E.place(g, 1);
  assert.equal(E.stats(g, g.buildings[0]).attack, 15); assert.equal(E.stats(g, g.buildings[1]).attack, 10);
  for (let i = 0; i < 30; i++) assert.equal(E.stats(g, g.buildings[0]).attack, 15);
  E.move(g, 1, 4); assert.equal(E.stats(g, g.buildings[0]).attack, 12);
  g.buildings.push({ id: 99, type: 'training', cell: 5, level: 2 }); assert.equal(E.stats(g, g.buildings[0]).attack, 18);
});
test('highest adjacent training field wins and training cards add to its percentage', () => {
  const g = E.createGame(); g.buildings.push({ id: 3, type: 'training', cell: 1, level: 1 }, { id: 4, type: 'training', cell: 4, level: 2 });
  g.boosts.legion = 1; assert.equal(E.stats(g, g.buildings[0]).attack, 21);
});
test('building upgrades change stats, cap at three, full camps still permit skipping', () => {
  const g = E.createGame(); E.choose(g, 'legion'); E.place(g, 0); assert.equal(E.stats(g, g.buildings[0]).hp, 180); assert.equal(E.stats(g, g.buildings[0]).attack, 18);
  g.phase = 'reward'; E.choose(g, 'legion'); E.place(g, 0); assert.equal(g.buildings[0].level, 3);
  g.phase = 'reward'; E.choose(g, 'legion'); assert(!E.place(g, 0)); assert(E.skip(g)); assert.equal(g.phase, 'prepare');
});
test('buildings cannot move into occupied cells or change deployment during battle', () => {
  const g = E.createGame(); E.skip(g); assert(!E.move(g, 1, 2)); assert(E.setLane(g, 2, 1)); E.start(g); assert(!E.move(g, 1, 4)); assert(!E.setLane(g, 2, 2)); assert(!E.start(g)); assert.equal(g.battle.units.filter(u => u.side === 'ally').length, 2);
});
test('unopposed enemies breach once per lane, not once per enemy', () => {
  const g = E.createGame(); g.round = 3; g.buildings = []; E.skip(g); E.start(g); play(g); assert.equal(g.defense, 2); assert.equal(g.phase, 'victory');
  const hp = g.defense; E.step(g, 1); assert.equal(g.defense, hp);
});
test('zero defense causes immediate defeat', () => {
  const g = E.createGame(); g.defense = 1; g.buildings = []; E.skip(g); E.start(g); play(g); assert.equal(g.defense, 0); assert.equal(g.phase, 'defeat'); assert.equal(g.history.length, 1);
});
test('simultaneous deaths count as a held lane', () => {
  const g = E.createGame(); E.skip(g); E.start(g);
  g.battle.units = [
    { id: 1, side: 'ally', type: 'legion', lane: 0, x: 400, hp: 10, maxHp: 10, attack: 10, range: 34, shield: 0, cooldown: 0, flash: 0 },
    { id: 2, side: 'enemy', type: 'enemy', lane: 0, x: 425, hp: 10, maxHp: 10, attack: 10, range: 34, shield: 0, cooldown: 0, flash: 0 }
  ]; E.step(g, 1 / 30); assert(g.battle.units.every(u => u.hp === 0)); assert.equal(g.battle.lanes[0], 'held'); assert.equal(g.defense, 5);
});
test('timeout resolves remaining enemies as a breach', () => {
  const g = E.createGame(); E.skip(g); E.start(g); g.battle.time = 59.99; E.step(g, 1 / 30); assert.equal(g.phase, 'result'); assert.equal(g.defense, 4);
});
test('shields absorb damage and clear before the next round while permanent training stays', () => {
  const g = E.createGame(); g.round = 2; E.choose(g, 'shield'); E.setShield(g, 0); g.boosts.legion = 1; E.start(g);
  const unit = g.battle.units.find(u => u.side === 'ally'); assert.equal(unit.shield, 40); play(g); E.next(g); assert.equal(g.shieldLane, null); assert.equal(g.boosts.legion, 1); E.skip(g); E.start(g);
  assert.equal(g.battle.units.find(u => u.side === 'ally').shield, 0); assert.equal(g.battle.units.find(u => u.side === 'ally').hp, 120);
});
test('whole three-round campaign terminates and a fresh game inherits nothing', () => {
  const g = E.createGame(); E.choose(g, 'training'); E.place(g, 1); E.start(g); play(g); assert.equal(g.phase, 'result'); E.next(g);
  E.choose(g, 'archerTrain'); E.start(g); play(g); assert.equal(g.phase, 'result'); E.next(g);
  E.choose(g, 'legion'); E.place(g, 5); E.setLane(g, 4, 1); E.start(g); play(g); assert.equal(g.phase, 'victory'); assert.equal(g.history.length, 3);
  for (let i = 0; i < 5; i++) { const fresh = E.createGame(); assert.equal(fresh.defense, 5); assert.equal(fresh.round, 1); assert.equal(fresh.boosts.archer, 0); assert.equal(fresh.buildings.length, 2); assert.equal(fresh.history.length, 0); }
  console.log('Sample campaign defense:', g.history.map(h => h.defense).join(' -> '));
});
