'use strict';
const assert=require('node:assert/strict'),{test}=require('node:test'),E=require('../dist/engine.js');
// Fixtures request a specific offer; production draws are tested separately.
const pick=(g,id)=>{if(g.phase==='reward'){g.offered=[id,...Object.keys(E.CARDS).filter(x=>x!==id).slice(0,2)];g.offerYear=g.round;}return E.choose(g,id);};
const play=g=>{let frames=0;while(g.phase==='battle'&&frames++<2300)E.step(g,1/30);assert.notEqual(g.phase,'battle');};
const unit=(id,side,x,y,extra={})=>({id,side,type:side==='ally'?'legion':'enemy',x,y,hp:100,maxHp:100,attack:10,range:72,speed:60,interval:1,shield:0,cooldown:0,flash:0,...extra});
function battle(units){const g=E.createGame();E.skip(g);E.start(g);g.battle.units=units;g.battle.initialAllies=units.filter(u=>u.side==='ally').length;g.battle.initialEnemies=units.filter(u=>u.side==='enemy').length;return g;}
test('cards grant once; invalid placement preserves pending reward',()=>{const g=E.createGame();assert(pick(g,'training'));assert(!pick(g,'legion'));assert(!E.place(g,0));assert.equal(g.pending,'training');assert(E.place(g,1));assert(!E.place(g,5));});
test('camp buildings stay fixed through upgrades, cards and battle; no relocation or lane API',()=>{const g=E.createGame(),before=g.buildings.map(b=>[b.id,b.cell]);assert.equal(E.move,undefined);assert.equal(E.setLane,undefined);pick(g,'legion');E.place(g,0);E.start(g);play(g);assert.deepEqual(g.buildings.map(b=>[b.id,b.cell]),before);assert(g.buildings.every(b=>!('lane'in b)));});
test('training buffs orthogonal neighbours only and highest adjacent bonus wins',()=>{const g=E.createGame();pick(g,'training');E.place(g,1);assert.equal(E.stats(g,g.buildings[0]).attack,17.5);assert.equal(E.stats(g,g.buildings[1]).attack,12.5);assert.equal(E.stats(g,g.buildings[2]).attack,30);g.buildings.push({id:9,type:'training',level:2,cell:4});g.boosts.legion=1;assert.equal(E.stats(g,g.buildings[0]).attack,24.5);});
test('three upgrade levels and invalid full-camp choices preserve rules',()=>{const g=E.createGame();for(let i=0;i<2;i++){g.phase='reward';pick(g,'legion');assert(E.place(g,0));}assert.equal(g.buildings[0].level,3);assert.equal(E.stats(g,g.buildings[0]).hp,300);g.phase='reward';pick(g,'legion');assert(!E.place(g,0));assert(E.skip(g));});
test('automatic role ranks use unit type, independently of camp cell position',()=>{const g=E.createGame();g.buildings.push({id:4,type:'legion',cell:11,level:1});const a=E.muster(g).filter(u=>u.side==='ally');const xs=type=>a.filter(u=>u.type===type).map(u=>u.x);assert(Math.min(...xs('legion'))>Math.max(...xs('archer')));assert(Math.min(...xs('archer'))>Math.max(...xs('siege')));assert.notEqual(a.filter(u=>u.type==='legion')[0].y,a.filter(u=>u.type==='legion')[1].y);g.buildings.forEach(b=>b.cell=11-b.cell);assert.deepEqual(E.muster(g).map(({x,y,type})=>({x,y,type})),E.muster({...g,buildings:g.buildings.map(b=>({...b,cell:11-b.cell}))}).map(({x,y,type})=>({x,y,type})));});
test('large formations have distinct positions and ordered role bands',()=>{const g=E.createGame();g.buildings=Array.from({length:12},(_,i)=>({id:i+1,type:i<8?'siege':i<10?'archer':'legion',cell:i,level:1}));const a=E.muster(g).filter(u=>u.side==='ally');assert.equal(new Set(a.map(u=>u.x+','+u.y)).size,12);assert(Math.max(...a.filter(u=>u.type==='siege').map(u=>u.x))<Math.min(...a.filter(u=>u.type==='archer').map(u=>u.x)));assert(a.every(u=>u.x>=0&&u.x<750&&Math.abs(u.y)<=290));});
test('units cross former lane boundaries and retarget surviving foes anywhere',()=>{const a=unit(1,'ally',300,-145),b=unit(2,'enemy',450,145),g=battle([a,b]);E.step(g,.1);assert(a.y>-145);assert(b.y<145);assert.equal(a.targetId,2);const c=unit(3,'enemy',480,-160);g.battle.units.push(c);b.hp=0;E.step(g,.1);assert.equal(a.targetId,3);});
test('frontline death lets enemies reach and attack the backline',()=>{const front=unit(1,'ally',400,0,{hp:1,attack:0}),rear=unit(2,'ally',250,0,{type:'archer',hp:50,attack:0,range:320}),foe=unit(3,'enemy',450,0,{attack:20}),g=battle([front,rear,foe]);for(let i=0;i<400&&g.phase==='battle';i++)E.step(g,1/30);assert.equal(front.hp,0);assert.equal(rear.hp,0);assert.equal(g.battle.report.won,false);});
test('siege stones travel before impact and splash only nearby enemies',()=>{const cat=unit(1,'ally',100,0,{type:'siege',range:510,attack:40,interval:3}),a=unit(2,'enemy',450,0,{speed:0}),b=unit(3,'enemy',450,80,{speed:0}),far=unit(4,'enemy',450,-170,{speed:0}),friend=unit(5,'ally',430,20,{attack:0}),g=battle([cat,a,b,far,friend]);E.step(g,1/30);assert.equal(a.hp,100);assert(g.battle.projectiles.some(p=>p.siege));for(let i=0;i<23;i++)E.step(g,1/30);assert(a.hp<100);assert(b.hp<100);assert.equal(far.hp,100);assert(friend.hp>=78,'only enemy melee can damage allies');});
test('whole-army shield applies immediately and expires between battles',()=>{const g=E.createGame();g.round=2;assert(pick(g,'shield'));assert.equal(g.phase,'prepare');E.start(g);assert(g.battle.units.filter(u=>u.side==='ally').every(u=>u.shield===40));play(g);E.next(g);assert.equal(g.armyShield,false);E.skip(g);E.start(g);assert(g.battle.units.filter(u=>u.side==='ally').every(u=>u.shield===0));});
test('defense resolves once for the shared field; zero defense ends campaign',()=>{const g=E.createGame();g.buildings=[];g.defense=1;E.skip(g);E.start(g);play(g);assert.equal(g.phase,'defeat');assert.equal(g.defense,0);assert.equal(g.history.length,1);E.step(g,1);assert.equal(g.history.length,1);});
test('simultaneous melee deaths count as a defended field',()=>{const g=battle([unit(1,'ally',400,0,{hp:10}),unit(2,'enemy',425,0,{hp:10})]);E.step(g,1/30);assert(g.battle.units.every(u=>u.hp===0));assert(g.battle.report.won);assert.equal(g.defense,3);});
test('pending enemy arrows resolve before declaring victory',()=>{const g=battle([unit(1,'ally',400,0,{hp:5}),unit(2,'enemy',450,0,{hp:0})]);g.battle.projectiles=[{target:1,side:'enemy',life:.1,damage:10}];E.step(g,1/30);assert.equal(g.phase,'battle');for(let i=0;i<4;i++)E.step(g,1/30);assert.equal(g.battle.units[0].hp,0);assert.notEqual(g.phase,'battle');});
test('shared-field timeout ends cleanly with one report',()=>{const g=E.createGame();E.skip(g);E.start(g);g.battle.time=74.99;E.step(g,1/30);assert.equal(g.phase,'result');assert.equal(g.history.length,1);assert.equal(g.battle.report.defenseLost,1);});
test('campaign continues into year four without relocation or lane assignment',()=>{const g=E.createGame();for(const [card,cell]of [['training',1],['siege',5],['legion',6]]){assert(pick(g,card));assert(E.place(g,cell));assert(E.start(g));play(g);if(g.phase==='result')E.next(g);}assert.equal(g.phase,'reward');assert.equal(g.round,4);assert.equal(g.history.length,3);const f=E.createGame();assert.equal(f.buildings.length,3);assert.equal(f.history.length,0);assert.equal(f.armyShield,false);});
test('enemy formation is deterministic within a year and grows without rerolls',()=>{
 const g=E.createGame();for(const year of [1,3,4,8,10,50,100000]){g.round=year;const a=E.muster(g).filter(u=>u.side==='enemy');E.offers(g);assert.deepEqual(E.muster(g).filter(u=>u.side==='enemy'),a);assert.equal(a.length,E.encounter(year).roster.length);assert.equal(new Set(a.map(u=>u.x+','+u.y)).size,a.length);assert(a.every(u=>u.x<=1050&&Math.abs(u.y)<=290));}
});
test('three failed years consume exactly three lives, then require a new campaign',()=>{
 const g=E.createGame();g.buildings=[];assert.equal(g.defense,3);
 for(let year=1;year<=3;year++){E.skip(g);E.start(g);play(g);assert.equal(g.defense,3-year);assert.equal(g.battle.report.defenseLost,1);E.step(g,1);assert.equal(g.defense,3-year);if(year<3){assert.equal(g.phase,'result');assert(E.next(g));}else{assert.equal(g.phase,'defeat');assert(!E.next(g));}}
 assert.equal(E.createGame().defense,3);
});
test('150 years continue with bounded history and without a final victory state',()=>{
 const g=E.createGame();for(let year=1;year<=150;year++){assert.equal(g.round,year);E.skip(g);assert(E.start(g));g.battle.units.filter(u=>u.side==='enemy').forEach(u=>u.hp=0);E.step(g,.1);assert.equal(g.phase,'result');assert(E.next(g));}
 assert.equal(g.round,151);assert.equal(g.defense,3);assert.equal(g.history.length,100);assert.equal(g.history[0].round,51);
});
test('fully upgraded camps still receive an actionable card every year',()=>{
 const g=E.createGame();g.buildings=Array.from({length:12},(_,i)=>({id:i,type:['legion','archer','siege','training'][i%4],cell:i,level:3}));g.boosts.legion=g.boosts.archer=2;
 for(let year=1;year<=12;year++){g.round=year;g.phase='reward';const card=E.offers(g).find(id=>E.canChoose(g,id));assert(card);assert(pick(g,card));assert.equal(g.phase,'prepare');}
});
test('Testudo is a separate battle-order card, affects only infantry and expires next year',()=>{
 const g=E.createGame(),buildings=JSON.stringify(g.buildings);assert(pick(g,'testudo'));assert(!pick(g,'testudo'));assert.equal(JSON.stringify(g.buildings),buildings);assert.equal(g.armyShield,false);
 E.start(g);for(const u of g.battle.units){assert.equal(!!u.testudo,u.type==='legion');if(u.side==='ally'){assert.equal(u.speed,E.TYPES[u.type].speed*(u.type==='legion'?.75:1));assert.equal(u.shield,0);}}
 play(g);assert(E.next(g));assert.equal(g.armyTestudo,false);assert(E.muster(g).every(u=>!u.testudo));
});
test('Testudo reduces melee and projectile damage before independent shield absorption',()=>{
 for(const ranged of [false,true]){
  const a=unit(1,'ally',400,0,{testudo:true,attack:0,shield:4}),b=unit(2,'enemy',440,0,{attack:20,cooldown:ranged?99:0}),g=battle([a,b]);
  if(ranged)g.battle.projectiles=[{target:1,side:'enemy',life:.01,damage:20}];E.step(g,.02);
  assert.equal(a.hp,92);assert.equal(a.shield,0);const hit=g.battle.events.find(e=>e.kind==='hit'&&e.id===1);assert.equal(hit.damage,8);assert.equal(hit.absorbed,4);
 }
 const a=unit(1,'ally',400,0,{attack:0}),b=unit(2,'enemy',440,0,{attack:20}),g=battle([a,b]);E.step(g,.02);assert.equal(a.hp,80);
});
