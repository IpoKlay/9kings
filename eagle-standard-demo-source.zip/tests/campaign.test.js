'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),E=require('../dist/engine.js'),L=require('../dist/i18n.js');
function fight(g){E.skip(g);E.start(g);let n=0;while(g.phase==='battle'&&n++<2400)E.step(g,1/30);assert.notEqual(g.phase,'battle');return g.battle.report;}
test('the unchanged starting army survives each of the first three years without supplies',()=>{for(const year of [1,2,3]){const g=E.createGame(1);g.round=year;assert(fight(g).won,'year '+year);assert.equal(g.defense,3);}});
test('enemy types unlock gradually and statistics grow every year with a bounded army',()=>{
 for(const year of [1,2,3])assert(E.encounter(year).roster.every(t=>t==='enemy'));
 for(const [year,type]of [[4,'archer'],[6,'guard'],[8,'cavalry'],[10,'siege']]){assert(!E.encounter(year-1).roster.includes(type));assert(E.encounter(year).roster.includes(type));}
 let hp=0,atk=0,count=0;for(let year=1;year<=200;year++){const wave=E.encounter(year);assert(wave.health>hp);assert(wave.attack>atk);assert(wave.roster.length>=count&&wave.roster.length<=20);hp=wave.health;atk=wave.attack;count=wave.roster.length;}
});
test('enemy ranged units fire real projectiles and shields absorb damage',()=>{
 const g=E.createGame();g.round=10;E.skip(g);E.start(g);const guard=g.battle.units.find(u=>u.side==='enemy'&&u.type==='guard');assert(guard.shield>30);
 const types=new Set();for(let i=0;i<1800&&g.phase==='battle';i++){E.step(g,1/30);for(const p of g.battle.projectiles.filter(p=>p.side==='enemy'))types.add(p.siege?'siege':'archer');}assert(types.has('archer'));assert(types.has('siege'));assert(g.battle.units.some(u=>u.side==='ally'&&u.hp<u.maxHp));
});
test('enemy cavalry receives no benefit from player Shock Charge doctrine',()=>{
 function damage(upgrade){const g=E.createGame();g.round=8;g.upgrades.charge=upgrade;E.skip(g);E.start(g);const horse=g.battle.units.find(u=>u.side==='enemy'&&u.type==='cavalry'),ally=g.battle.units.find(u=>u.side==='ally'&&u.type==='legion');g.battle.units=[ally,horse];ally.x=400;horse.x=450;ally.y=horse.y=0;horse.cooldown=0;ally.cooldown=99;E.step(g,.01);return ally.maxHp-ally.hp;}assert.equal(damage(0),damage(1));
});
test('all cards, troop names, effects and synergy descriptions have Chinese translations',()=>{
 L.set('zh');for(const data of Object.values(E.CARDS)){const c=L.card(data);assert.notEqual(c.name,data.name);assert.notEqual(c.text,data.text);assert(!/[A-Za-z]{3}/.test(c.detail),data.name);assert.equal(c.kind,data.kind);}
 for(const t of Object.values(E.TYPES)){assert.notEqual(L.t(t.name),t.name);if(t.unit)assert.notEqual(L.t(t.unit),t.unit);}
 for(const c of E.synergies(E.createGame())){assert.notEqual(L.t(c.name),c.name);assert.notEqual(L.t(c.text),c.text);}assert.equal(L.fx('KILL STREAK ×3'),'连斩 ×3');assert.equal(L.year(14),'第 14 年');
 L.set('en');for(const data of Object.values(E.CARDS)){const c=L.card(data);assert.equal(c.name,data.name);assert.equal(c.text,data.text);}assert.equal(L.year(14),'YEAR 14');
});
test('language switching is reversible without changing a draw or campaign state',()=>{const g=E.createGame(5),offers=E.offers(g),before=JSON.stringify(g);for(const lang of ['zh','en','zh','en']){L.set(lang);offers.forEach(id=>L.card(E.CARDS[id]));assert.deepEqual(E.offers(g),offers);assert.equal(JSON.stringify(g),before);}});
test('a combined-arms doctrine build changes a mid-campaign defeat into a victory',()=>{
 const result=upgrades=>{const g=E.createGame(1);g.round=16;g.buildings=['guard','legion','spear','archer','archer','siege','medic'].map((type,i)=>({type,id:i+1,cell:i,level:1}));g.upgrades=upgrades;return fight(g);};
 assert.equal(result({}).won,false);const synergy=result({fireArrows:1,oilShots:1,pinning:1,shieldDrill:2,fieldMedicine:1,crossfire:1,combinedArms:1});assert(synergy.won);assert(synergy.surviving>=1);
});
