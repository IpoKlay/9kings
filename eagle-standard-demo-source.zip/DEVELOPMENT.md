# Under the Eagle · Frontier Campaign v0.14

A Chinese / English isometric legion strategy demo. Open `鹰旗之下-Demo.html` to play offline with all art and audio embedded.

## Cold Iron

Deep woodland greens, steel-grey mud, scorched earth, waterlogged craters, burnt woodland, broken equipment and small fires replace the pale meadow. Blood stains and fallen soldiers remain on the battlefield until the next round. Effects are bounded and respect reduced-motion settings.

World soldiers, camp buildings and catapults render at 70% of their v0.9 size. The wide camera remains in place; cards and controls retain their size. Use the gear button to switch between Chinese and English; the language preference is saved locally.

## Endless years

The year appears at the top center. Three perspective shields behind the rear palisade show remaining camp lives. There is no title badge or corner status panel. Each year draws three unique, usable cards from a 24-card pool. Previous-year offers are excluded whenever enough fresh choices exist. Capped upgrades and unsupported doctrines are filtered out; a full, fully upgraded camp still receives three single-battle orders. The latest 100 year reports are retained in memory.

## Shared battlefield

Buildings stay fixed after construction and can be upgraded in place. Infantry automatically forms the front line, archers the middle, and catapults the rear. Squads pursue and support each other across one shared battlefield. Catapults cause area damage; Hold Fast gives every allied squad 40 shield for the next battle.

Choose a supply card (or press 1 / 2 / 3), build in an empty camp cell or upgrade a matching building, then click MARCH. Battle supports pause, 1× / 2× / 4× speed, and M to toggle audio. Survive unlimited years. Enemy armies grow each year. The first three years remain gentle; archers arrive in year 4, guards in year 6, cavalry in year 8 and catapults in year 10. Start with three lives and lose exactly one per failed year. The third failed year ends the campaign. No save system or metaprogression is included.

## Development

- `node --test tests/*.test.js` — 49 checks covering combat, formations, rendering projection, audio and persistent battle marks.
- `python scripts/package-offline.py` — rebuild the offline HTML and ZIP.
- `dist/engine.js` — battle rules and automatic formations.
- `dist/app.js` — rendering and interface.
- `dist/isometric.js` — camera, terrain, structures and atmosphere.
- `dist/feedback.js` — combat feedback, blood and fallen soldiers.
- `dist/AUDIO-CREDITS.txt` — audio sources and licenses.

## v0.12 — Approved troop art and Testudo

- Imports the approved Aseprite AI Artist v4 troop layers. The 32×32 master uses a foot pivot of (16,28) and exactly one 0.7 draw scale; the already reduced PNGs are reference exports, never scaled again at runtime.
- Infantry uses the approved red shield layers. Archers retain the same body proportions with bow equipment; enemies use blue-grey armour and round shields. Each visible soldier keeps independent pose timing. Wounds and battle blood remain visible.
- Existing buildings, catapults, terrain, camera, sound and campaign rules are retained. No buildings from the art reference are imported.
- **Testudo** is an independent defensive formation card, drawn randomly from the yearly pool. It affects legionaries for the next battle: 40% less incoming damage, 25% lower movement speed. Front soldiers keep their shields forward while rear soldiers form the roof. It expires on advancing the year. **Hold Fast** remains a separate whole-army 40-shield order.
- Rule-level squads remain nine individually drawn soldiers; the new art does not change squad counts or health rules. Normal spacing and Testudo spacing remain distinct.
- Validation: 32 automated checks, including Testudo scope, expiry and reduction before shield absorption; browser selection, battle and result flow.

## v0.13 — Legion Doctrines

24 cards: 8 buildings, 12 permanent doctrines and 4 single-battle orders. New troop types are Spearmen (long reach and slowing hits), Shield Guards (heavy health and starting shields), Cavalry (fast first-strike charges) and Field Medics (healing support). All seven troop types form by role on one battlefield, independently of camp tile position.

- Fire Arrows → Pitch Stones: burning enemies take 50% more catapult damage.
- Spearmen → Pin & Pierce: slowed enemies take 30% more archer and siege damage.
- Iron Wall / Shield Guards → Field Medicine: frontline shields and medic healing sustain the army.
- Shock Charge → Blood & Glory: cavalry opens with a strong strike; kills give nearby allies 30% attack-rate haste for 3 seconds.
- Melee engagement → Crossfire: archers gain 25% damage per doctrine rank against engaged targets.
- United Legion rewards distinct troop types with 5% army attack each, up to 35%.

The BUILD panel lists your army, permanent doctrines, current orders and active or potential synergies. Card faces show their effect and duration. Hover for construction details. Choices remain stable within a year; repeated UI renders never reroll them. Ordinary troops do not need a doctrine to function.

Enemy difficulty is deliberately unchanged: exactly three enemy squads with the same health, attack, speed, range, attack interval and formation every year. Lives remain three and the campaign has no final year. No persistence between page reloads.

Validation: 42 automated checks, including 100 seeded campaigns of up to 12 years, anti-repeat draws, full-camp fallback, healing, burn / siege interactions, slowing / ranged interactions, cavalry charges, permanent stacking and temporary expiry. Existing audio, formations and Testudo checks remain covered.

## v0.14 — Frontier Campaign / 边境战役

- Chinese is the first-launch default. The gear button switches between Chinese and English without resetting the campaign or rerolling cards. Both languages cover cards, buildings, doctrines, year labels, reports, combat captions, settings and accessibility labels.
- Settings include sound enable/disable, master volume, war-cry volume and impact feedback. Opening a dialog pauses combat; preferences persist locally. Campaign progress still does not persist across reloads.
- Years 1–3 field three infantry squads. Archers arrive in year 4; guards with shields in year 6; cavalry with first-strike charges in year 8; ranged area-damage catapults in year 10. Later rosters rotate their mix. Preview the current army under the year label before choosing supplies.
- Enemy count is `min(20, 3 + floor(max(0, year - 2) / 2))`. HP multiplier is `1 + .025*(year-1) + .012*max(0,year-8)`. Attack multiplier is `1 + .018*(year-1) + .008*max(0,year-8)`. Speed and attack interval remain constant by type. The cap bounds rendering cost; health and attack continue increasing. Enemy generation never consumes card RNG.
- Enemy ranged troops launch real arrows and stones; heavy guards have shields; cavalry charges do not inherit the player's Shock Charge doctrine. Enemy uniforms stay blue-grey.
- Validation: 49 automated checks and bilingual browser checks. The starting army survives years 1–3 without supplies. A fixed seven-squad formation loses in year 16 without doctrines but wins with the documented combined build. `node scripts/balance-report.js` compares example builds and 20 seeded campaigns per simple policy; this is a tuning probe, not a claim of final balance.

### Collaboration and play access

The public game is https://ipoklay.github.io/eagle-standard-demo/ and does not need a repository invitation. Private design documents stay in `IpoKlay/9kings`. Repository collaborators and GitHub App repository authorization are separate permissions; share the playable URL for playtests.
