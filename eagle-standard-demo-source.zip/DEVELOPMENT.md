# Under the Eagle · Cold Iron v0.10

An English-language isometric legion strategy demo. Open `鹰旗之下-Demo.html` to play offline with all art and audio embedded.

## Cold Iron

Deep woodland greens, steel-grey mud, scorched earth, waterlogged craters, burnt woodland, broken equipment and small fires replace the pale meadow. Blood stains and fallen soldiers remain on the battlefield until the next round. Effects are bounded and respect reduced-motion settings.

World soldiers, camp buildings and catapults render at 70% of their v0.9 size. The wide camera remains in place; cards and controls retain their size. The interface, card descriptions, accessibility labels and battle reports are in English.

## Shared battlefield

Buildings stay fixed after construction and can be upgraded in place. Infantry automatically forms the front line, archers the middle, and catapults the rear. Squads pursue and support each other across one shared battlefield. Catapults cause area damage; Hold Fast gives every allied squad 40 shield for the next battle.

Choose a supply card (or press 1 / 2 / 3), build in an empty camp cell or upgrade a matching building, then click MARCH. Battle supports pause, 1× / 2× / 4× speed, and M to toggle audio. Survive three rounds with camp defense remaining to win. No save system or metaprogression is included.

## Development

- `node --test tests/*.test.js` — 26 checks covering combat, formations, rendering projection, audio and persistent battle marks.
- `python scripts/package-offline.py` — rebuild the offline HTML and ZIP.
- `dist/engine.js` — battle rules and automatic formations.
- `dist/app.js` — rendering and interface.
- `dist/isometric.js` — camera, terrain, structures and atmosphere.
- `dist/feedback.js` — combat feedback, blood and fallen soldiers.
- `dist/AUDIO-CREDITS.txt` — audio sources and licenses.
